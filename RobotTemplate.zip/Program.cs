﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ClientLibrary.robot;
using ClientLibrary.config;
using BaseLibrary.command.common;
using BaseLibrary.utils;
using BaseLibrary.equip;

namespace $safeprojectname$ {
    class Program {
        static void Main(string[] args) {
            ClientRobot.Connect(args);
            Tank firstTank = new Tank("My first tank", ClientRobot.TEAM_NAME);
        }
    }
}
